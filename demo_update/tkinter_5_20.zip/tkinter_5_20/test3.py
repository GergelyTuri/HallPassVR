from tkinter import *
#import tkinter as tk
from PIL import ImageTk, Image
from tkinter import filedialog
import os
import numpy as np 
import time
from threading import Thread
import sys

root = Tk()

test = open("test.txt", "r+")


new_4 = [1,2,3,4] #assume output

temp_12 = test.read()
temp_12_array = temp_12.split()

print("The original list is : " + str(temp_12_array))

repl_list_strt_idx = 0
repl_list_end_idx = 4

temp_12_array[repl_list_strt_idx : repl_list_end_idx] = new_4

new_12_array = temp_12_array

print("The original list is : " + str(new_12_array))




new_string_ints_12 = [str(int) for int in new_12_array]
new_str_of_ints_12 = " ".join(new_string_ints_12)


#listToString(result_t

print(temp_12_array[10])


test.seek(0)

test.write(new_str_of_ints_12)

test.close()
root.mainloop()


#background_thread.exit()