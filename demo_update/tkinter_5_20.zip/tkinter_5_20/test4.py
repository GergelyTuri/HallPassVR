from tkinter import *
#import tkinter as tk
from PIL import ImageTk, Image
from tkinter import filedialog
import os
import numpy as np 
import time
from threading import Thread
import sys

root = Tk()
  
test_list = [4, 5, 6, 7, 10, 2]

test_list2 = [0 for i in range(12)]

string = "image/white.jpg"
string2 = "image/black.jpg"

test_list3 = [string for i in range(12)]

   
# Replace list 
repl_list_strt_idx = 0
repl_list_end_idx = 4

new_list = [11, 1, 4, 3]

new_list2 = [string2 for i in range(4)]

def list_gen(old_list, new_list, repl_list_strt_idx, repl_list_end_idx):
    print("The original list is : " + str(old_list))

    old_list[repl_list_strt_idx : repl_list_end_idx] = new_list2

    new_list = old_list

    print("new list is: ", new_list)

list_gen(test_list3, new_list, repl_list_strt_idx, repl_list_end_idx)


root.mainloop()

#background_thread.exit()