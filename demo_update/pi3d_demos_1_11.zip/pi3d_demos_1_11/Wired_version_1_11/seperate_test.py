#Note: avoid per-pixel loops in Python

#use for function test

from   tkinter   import *
from   PIL       import ImageTk, Image
from   tkinter   import filedialog
import os
import numpy     as np 
from   tkinter   import messagebox
import time
from   threading import Thread
import datetime
import linecache
import glob
import shutil
from os import path
import re

#from GUI_Interface_demo_11_9 import ELEMENT_CONVERT_TABLE

#from GUI_Interface_demo_11_9 import ADD_PATTERN

#from GUI_Interface_demo_11_9 import CURRSEL_ELEMENT, ELEMENT_CONVERT_TABLE

#generate different element name based on element name

string_dir = 'image/ELEMENT'
extensions = [".jpg", ".png", ]

ELEMENT_LIST = []

CODENAME_LIST = []

ELEMENT_CONVERT = {"Name":[], "DECODE_NAME":[]}

ELEMENT_LIST = [f for f in os.listdir(string_dir) if os.path.splitext(f)[1] in extensions]

const = -1
const_loop = -2

for element in ELEMENT_LIST:
    ELEMENT_CONVERT["Name"].append(element)
    
    element = element[:element.index('.')]
    CODE_NAME = element[0] + element[const]
    
    while CODE_NAME in CODENAME_LIST:
        CODE_NAME = element[0] + element[const_loop]
        const_loop = const_loop -1 
        #print(CODE_NAME)
        
    CODENAME_LIST.append(CODE_NAME)
    ELEMENT_CONVERT["DECODE_NAME"].append(CODE_NAME)
    
    #print(CODE_NAME)

#print(ELEMENT_CONVERT)    
#print(CODENAME_LIST)

#simulate the part combine element 
#1) name 
ADD_ELEMENT = 'image/ELEMENT/'
ADD_PATTERN = 'image/HIST_PATTERN/'
CURRSEL_ELEMENT_GEN = [4, 1, 3, 2]

COMB_IMAGE_DECODE_NAME_LIST = [ELEMENT_CONVERT["DECODE_NAME"][x] for x in CURRSEL_ELEMENT_GEN]

print(COMB_IMAGE_DECODE_NAME_LIST)

#print(CURRSEL_ELEMENT_GEN[1])
try:
    COMB_IMAGE_NAME_LIST = [Image.open(y) for y in [ADD_ELEMENT+ ELEMENT_CONVERT["Name"][x] for x in CURRSEL_ELEMENT_GEN]]
except:
    print("IMAGE NOT FOUND")

WIDTHS, HEIGHTS = zip(*(i.size for i in COMB_IMAGE_NAME_LIST))

total_width = sum(WIDTHS)

max_height = max(HEIGHTS)

new_im = Image.new('RGB', (total_width, max_height))

x_offset = 0

for im in COMB_IMAGE_NAME_LIST:
    new_im.paste(im, (x_offset,0))
    x_offset += im.size[0]
    
GEN_PATTERN_NAME = ''.join(COMB_IMAGE_DECODE_NAME_LIST)
name = ADD_PATTERN + GEN_PATTERN_NAME +'.jpg'

#print(name)

new_im.save(ADD_PATTERN + GEN_PATTERN_NAME +'.jpg')

#print(COMB_IMAGE_NAME_LIST)


#decode 
SEP_PATTERN_NAME = re.findall('..',GEN_PATTERN_NAME)
print(SEP_PATTERN_NAME)

key_list = list(ELEMENT_CONVERT['DECODE_NAME'])
#print(key_list)

position = key_list.index('c5')
#print(position)

CURRSEL_ELEMENT_GEN_SELF_CHECK = []

for element in SEP_PATTERN_NAME:
    position = list(ELEMENT_CONVERT['DECODE_NAME']).index(element)
    
    CURRSEL_ELEMENT_GEN_SELF_CHECK.append(position)
    
print(CURRSEL_ELEMENT_GEN_SELF_CHECK)







    
