from re import L
from tkinter import *
import os
import time
import json
from json.decoder import JSONDecodeError

from screeninfo import get_monitors

root = Tk()

#root.geometry("10x10+2500+200")

# 2022-01-05-13_06_50 test0105 [1,1,1]
# 2022-01-05-12_20_27 ssssddd [3,0,0]
# 2022-01-05-18_24_36 TEST021 120



def CORRIDOR_OPEN():
	#os.system('python3 Corridor_demo_1_11.py')
	#time.sleep(0.001)
	#root.destroy()
	for monitor in get_monitors():
		width = monitor.width
		height = monitor.height
 
		print(str(width) + 'x' + str(height))
	#pass



    
#button = Button(root, text = "button", width = 10, height = 10, command = test_case)

root.wait_visibility()
#CORRIDOR_OPEN()
#DECODE_INITIAL()
#FINAL_SELF_CHECK()
CORRIDOR_OPEN()
root.mainloop()



#pattern1 : 0->3
#pattern2 : 4->7
#pattern3 : 8->11

#CASE  RED BLK YELLOW  1 1 1
#	   RED RED RED  3 0 0
#		RED RED BLUE 2 0 1
#		RED BLUE BLUE 1 2 0 
#		RED BLUE RED 2 1 0
