import tkinter as tk

root = tk.Tk()

screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()

print("screen_width: %d, screen_height : %d", screen_width, screen_height)
