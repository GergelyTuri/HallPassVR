from tkinter import *
#import tkinter as tk
from PIL import ImageTk, Image
from tkinter import filedialog
import os
import numpy as np 
import time
from threading import Thread
import sys
from multiprocessing import Process, Pipe
#from test3 import nameit

root = Tk()

click_count = 0

share = open("test.txt", "w")


#greet = nameit("yazebon")
  
print("hehe bitchass, I am here")

global array 
array = [11,22,33,44]

Button_ADD = Button(root, text = "Add", width = 5, height = 2, command=lambda: [input(), os.system('python test5.py')])
Button_ADD.pack()



def test():
    print(" in here for test")


def main():
    #input()
    root.mainloop()


def input():
    global array

    array_num = [str(int) for int in array]
    final_array_num = " ".join(array_num)

    print("in here for test2")
    share.write(str(final_array_num))
    share.close()


if __name__ == '__main__':
    main()

#background_thread.exit()