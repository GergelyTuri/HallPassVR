from multiprocessing import Process, Pipe

from tkinter import *
#import tkinter as tk
from PIL import ImageTk, Image
from tkinter import filedialog
import os
from os import path
import numpy as np 
import time
from threading import Thread
import sys
import shutil
import linecache

root = Tk()
history_comb_path = 'test/HistoryComb/'
teststring = 'HistoryComb 0003'


def delete_hi():
    teststring2string = teststring.split()
    click_line_mark = teststring2string[1]
    size_1 = len(teststring2string[1])
    print("testing number is :", teststring2string[1], " testing size is: ", size_1)

    line_list = []

    #print(click_line)

    readfile = open("test.txt", "r")
    count = 1
    while True: 
        line = readfile.readline()
             
        if line == "":
            pass
        else: 
            click_line = line.split('\n')[0]
            print("click line is: ", click_line)
            click_line_split = click_line.split(' , ')[0]
            res = ''.join(filter(lambda i: i.isdigit(), click_line_split))
            print(str(res))

            compare_last_digt = str(res).zfill(4)
            print("the compare number is: ", compare_last_digt)

            if compare_last_digt == click_line_mark:
                #print("the list already exist", display_list)
                print("match here, the count number is: ", count)
                pass  
            else:
                line_list.append(click_line)
        
        count += 1

        if not line:
            break
        
    readfile.close()
    print(line_list)

    readfile = open("test.txt", "w")
    for item in line_list:
        readfile.write(item)
        readfile.write('\n')

    readfile.close()
    

    find_path_string = history_comb_path + teststring + '.jpg'
    print(find_path_string)

    if path.exists(find_path_string):
        print("just for test")
        os.remove(find_path_string)
    else:
        print("not here")


def f(child_conn):
    msg = 0
    child_conn.send(msg)
    child_conn.close()
    msg +=1 




def main():
    delete_hi()
    root.mainloop()



def test():
    folder = 'test/HistoryComb'
    for filename in os.listdir(folder):
        file_path = os.path.join(folder, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
        except Exception as e:
            print('Failed to delete %s. Reason: %s' % (file_path, e))


if __name__ == '__main__':
    main()