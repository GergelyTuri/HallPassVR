from tkinter import *
#import tkinter as tk
from PIL import ImageTk, Image
from tkinter import filedialog
import os
import numpy as np 
import time
from threading import Thread
from tkinter import messagebox
import sys
import time
#from test4 import click_count

root = Tk()
i = 0

sentence = "HistoryComb5 , 9 9 9 9"
sentence2 = [3, 2, 1, 4]

def sentence2list():
    sentence2array = sentence.split(",")
    sentence2array = sentence2array[1]

    print(sentence2array)

    array2list = [int(x) for x in sentence2array.split()]
    print(array2list)



def test2():
    print("history comb read in here")
    string_dir = 'image/HistoryComb'
    history_comb_path = 'image/HistoryComb/'
    extensions = [".jpg"]

    History_comb_list  = [f for f in os.listdir(string_dir) if os.path.splitext(f)[1] in extensions]
    path2historyComb   = [history_comb_path + x for x in History_comb_list]
    History_comb_list_test = sorted(History_comb_list)
    print(History_comb_list_test)
    image = Image.open(path2historyComb[2])
    image.show()
    image2 = image.copy()
    image2.save("testimg.jpg")



def test3(sentence):
    test = open("historyCombCount.txt", "r+")

    while True: 
        a = test.readline()
        if a == "":
            pass
        else: 
            a2list = a.split(" , ")
            #print(a2list[1])
            display_list = [int(x) for x in a2list[1].split()]
            print (display_list)

            if sentence == display_list:
                print("in here, the list is: ", display_list)
                break 

        if not a:
            break

    test.close()

def popup():
    print("in here")
    result=messagebox.askquestion('Installation','Do you want to install this anyway?')
    if result=='yes':
        theLabel=Label(root,text="Enjoy this software.") #To insert a text
        theLabel.pack()
    else:
        root.destroy() #Closing Tkinter window forcefully.


#HistoryComb 3.jpg
def last_4chars(x):
    print("in here")
    



def test():
    global i 
    while True:
     i = i+1
     print(i)

     if i == 20:
         break
    

if __name__ == '__main__':
    i = 0
    test3(sentence2)
    test()
    popup()
    root.mainloop()

#background_thread.exit()