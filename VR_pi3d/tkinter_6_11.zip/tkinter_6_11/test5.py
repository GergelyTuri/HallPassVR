from multiprocessing import Process,Queue,Pipe


from tkinter import *
#import tkinter as tk
from PIL import ImageTk, Image
from tkinter import filedialog
import os
import numpy as np 
import time
from threading import Thread
import sys

import tkinter as tk
  
  
root = tk.Tk()
root.geometry("200x100")

def getTextInput():
    global result_length
    global result_name

    result_name=textBox.get()
    print(result_name)

  
textBox = Entry(root)
textBox.insert(0, "This is the default text")
textBox.pack()

Button_Input      = Button(root,       text = "Read",       width = 7,  height = 2, command = getTextInput)
Button_Input.pack()
root.mainloop()

