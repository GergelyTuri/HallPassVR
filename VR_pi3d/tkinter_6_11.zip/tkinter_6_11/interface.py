from tkinter import * 
from PIL import ImageTk, Image

root = Tk()

#DEFINE STRING VARABLE



#LOOP 1
Label1= Label(root, text =" loop 1")
Label1.grid(row = 0, column = 0)

clicked1 = StringVar()
clicked1.set("default ")
drop = OptionMenu(root, clicked1, "none", "patten 1", "patten 2", "patten 3")
drop.grid(row = 0, column = 1)

clicked2 = StringVar()
clicked2.set("default ")
drop2 = OptionMenu(root, clicked2, "none", "patten 1", "patten 2", "patten 3")
drop2.grid(row = 0, column = 2)

clicked3 = StringVar()
clicked3.set("default ")
drop3 = OptionMenu(root, clicked3, "none", "patten 1", "patten 2", "patten 3")
drop3.grid(row = 0, column = 3)

clicked4 = StringVar()
clicked4.set("default ")
drop4 = OptionMenu(root, clicked4, "none", "patten 1", "patten 2", "patten 3")
drop4.grid(row = 0, column = 4)

var1 = IntVar()
c1= Checkbutton(root, text = "enable", variable = var1)
c1.grid(row = 0, column = 5)



#for loop 2
Label2= Label(root, text =" loop 2")
Label2.grid(row = 1, column = 0)

var2 = IntVar()
c2= Checkbutton(root, text = "enable", variable = var2)
c2.grid(row = 1, column = 1)




#for loop3
Label3= Label(root, text =" loop 3")
Label3.grid(row = 2, column = 0)

var3 = IntVar()
c3= Checkbutton(root, text = "enable", variable = var3)
c3.grid(row = 2, column = 1)





#for loop4
Label4= Label(root, text =" loop 4")
Label4.grid(row = 3, column = 0)

var4 = IntVar()
c4= Checkbutton(root, text = "enable", variable = var4)
c4.grid(row = 3, column = 1)




#for loop5
Label5= Label(root, text =" loop 5")
Label5.grid(row = 4, column = 0)


var5 = IntVar()
c5 = Checkbutton(root, text = "enable", variable = var5)
c5.grid(row = 4, column = 1)


#PATTERN VIEWING WINDOW 

list1 = Listbox(root, height = 6, width = 35)
list1.grid(row = 5, column = 0, columnspan = 4)

scrobar = Scrollbar(root)
scrobar.grid(row = 5, column = 4)

list1.configure(yscrollcommand = scrobar.set)
scrobar.configure(command = list1.yview)

#ADD PATTERN TO DATABASE



root.mainloop()