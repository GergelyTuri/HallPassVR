from re import L
from tkinter import *
import os
import time
import json
from json.decoder import JSONDecodeError

root = Tk()

#root.geometry("10x10+2500+200")

# 2022-01-05-13_06_50 test0105 [1,1,1]
# 2022-01-05-12_20_27 ssssddd [3,0,0]
# 2022-01-05-18_24_36 TEST021 120



def CORRIDOR_OPEN():
	os.system('python GUI_FORM.py')
	time.sleep(0.001)
	root.destroy()
	pass


global ELEMENT_LIST 
ELEMENT_LIST = []

global ELEMENT_CONVERT_TABLE
ELEMENT_CONVERT_TABLE = {"NAME":[], "DECODE_NAME":[]}

global CODENAME_LIST
CODENAME_LIST = []
    
def DECODE_INITIAL():
    
    global ELEMENT_LIST
    global ELEMENT_CONVERT_TABLE
    
    extensions = [".jpg", ".png" ]
    ELEMENT_LIST = []
    ELEMENT_LIST = [f for f in os.listdir('image/ELEMENT') 
            if os.path.splitext(f)[1] in extensions]

    const = -1
    const_loop = -2
    #global CODENAME_LIST
    for element in ELEMENT_LIST:
        ELEMENT_CONVERT_TABLE["NAME"].append(element)
    
        element = element[:element.index('.')]
        CODE_NAME = element[0] + element[const]
    
        while CODE_NAME in CODENAME_LIST:
            CODE_NAME = element[0] + element[const_loop]
            const_loop = const_loop -1 
        #print(CODE_NAME)
        
        CODENAME_LIST.append(CODE_NAME)
        ELEMENT_CONVERT_TABLE["DECODE_NAME"].append(CODE_NAME)
        	
    #print(ELEMENT_LIST)
    
    #print(ELEMENT_CONVERT_TABLE['DECODE_NAME'])
    
    
	
 
def FINAL_SELF_CHECK():
    PATH_DICT = {}
    
    PATH_VALUE_DICT = {}
    INPUT_DICT = {}
    PATTERN_1 = {}
    PATTERN_2 = {}
    PATTERN_3 = {}
    
    REF_PATH_DECODE_INDEX = []
    GOLDEN_PATH_DECODE_INDEX = []
    
    REF_PATH_NAME_IMG = []
    GOLDEN_PATH_NAME_IMG = []
    
    REF_PATH_NUM_DIG = []
    GOLDEN_PATH_NUM_DIG = []
    
    #global ELEMENT_CONVERT_TABLE
    #global CODENAME_LIST
    
    
     
    transpt = open('trash.txt', 'r')
    
    PATH_NAME = transpt.readline()
    
    #PATH_NAME = '2022-01-05-13_06_50 test0105' #111
    #PATH_NAME = '2022-01-05-18_10_32 TEST210' #201
    #PATH_NAME = '2022-01-05-12_20_27 ssssddd' #300
    #PATH_NAME = '2022-01-05-18_24_36 TEST021'  #120
    #PATH_NAME = '2022-01-05-18_45_55 SDSD210' #210
    
    NOTE = [0, 0, 0]
    transpt.close()
    
    with open('image/HIST_PATH/PATH.json', 'r') as f:
        try:
            PATH_DICT = json.loads(f.read())
            
            if PATH_DICT:
                #print (PATH_DICT)
                if (PATH_NAME in PATH_DICT):
                    PATH_VALUE_DICT = PATH_DICT[PATH_NAME]
                    NOTE = PATH_VALUE_DICT['Note']
                    INPUT_DICT = PATH_VALUE_DICT['INPUT']
                    
                    FLOOR_IMG = INPUT_DICT['Floor']
                    CEILING_IMG = INPUT_DICT['Ceiling']
                    LEN_PATH = INPUT_DICT['Path Length']
                    
                    print('floor img is :', FLOOR_IMG)
                    print('Ceiling img is :', CEILING_IMG)
                    print("path length is :", LEN_PATH)
                    #print(list(PATH_VALUE_DICT.values())[0]['ELEMENT_DECODE_INDEX'])
                    
                    
                else:
                   print("ERROR is either JSON file or PATH_NAME") 
        except JSONDecodeError:
            print("ERROR exists in PATH_PROCESS reading PATH JSON")
            
    #print(NOTE)  
      
    
    if (NOTE == [3,0,0]):
        PATTERN_1 = list(PATH_VALUE_DICT.values())[0]
        PATTERN_2 = PATTERN_1
        PATTERN_3 = PATTERN_2
        #print("PATTERN for [3,0,0] is :", PATTERN_1) #read the only pattern
    elif (NOTE == [2, 0, 1]): #[2,0,1] = [0,2,1]
        #print(PATH_VALUE_DICT)
        PATTERN_1 = list(PATH_VALUE_DICT.values())[0]
        PATTERN_2 = PATTERN_1
        PATTERN_3 = list(PATH_VALUE_DICT.values())[1]
        
    elif (NOTE == [1,2,0]): #[1,2,0] = [0,1,2]
        PATTERN_1 = list(PATH_VALUE_DICT.values())[0]
        PATTERN_2 = list(PATH_VALUE_DICT.values())[1]
        PATTERN_3 = PATTERN_2
        
    elif (NOTE == [1,1,1]):
        PATTERN_1 = list(PATH_VALUE_DICT.values())[0]
        PATTERN_2 = list(PATH_VALUE_DICT.values())[1]
        PATTERN_3 = list(PATH_VALUE_DICT.values())[2]
        
    elif (NOTE == [2,1,0]):
        PATTERN_1 = list(PATH_VALUE_DICT.values())[0]
        PATTERN_2 = list(PATH_VALUE_DICT.values())[1]
        PATTERN_3 = PATTERN_1       
        
    REF_PATH_DECODE_INDEX[0:3] = PATTERN_1['ELEMENT_DECODE_INDEX']
    REF_PATH_DECODE_INDEX[4:7] = PATTERN_2['ELEMENT_DECODE_INDEX']
    REF_PATH_DECODE_INDEX[8:11] = PATTERN_3['ELEMENT_DECODE_INDEX']
    
    REF_PATH_NAME_IMG[0:3] = PATTERN_1['ELEMENT_NAME_IMG']
    REF_PATH_NAME_IMG[4:7] = PATTERN_2['ELEMENT_NAME_IMG']
    REF_PATH_NAME_IMG[8:11] = PATTERN_3['ELEMENT_NAME_IMG']
    
    REF_PATH_NUM_DIG[0:3] =  PATTERN_1['ELEMENT_NUM_DIG']
    REF_PATH_NUM_DIG[4:7] =  PATTERN_2['ELEMENT_NUM_DIG']
    REF_PATH_NUM_DIG[8:11] =  PATTERN_3['ELEMENT_NUM_DIG']
    
    
    
    
    #print(REF_PATH_DECODE_INDEX)
    #print(REF_PATH_NAME_IMG)
    #print(REF_PATH_NUM_DIG)
    #print(ELEMENT_CONVERT_TABLE)
    
    for element in REF_PATH_NUM_DIG:
        GOLDEN_PATH_DECODE_INDEX.append(ELEMENT_CONVERT_TABLE['DECODE_NAME'][element])
        #print("index :", GOLDEN_PATH_DECODE_INDEX)
        GOLDEN_PATH_NAME_IMG.append(ELEMENT_CONVERT_TABLE['NAME'][element])
        #print(ELEMENT_CONVERT_TABLE['NAME'][element])
        
        
    #print(GOLDEN_PATH_DECODE_INDEX)
    #print(GOLDEN_PATH_NAME_IMG)
    

    if ((GOLDEN_PATH_DECODE_INDEX == REF_PATH_DECODE_INDEX) 
        and (GOLDEN_PATH_NAME_IMG == REF_PATH_NAME_IMG)):
        print('CORRIDOR SELF CHECK PASSED')
    else:
        print("ERROR EXIST in VR CORRIDOR INITIAL SELF CHECK")
        
    
    
    

#button = Button(root, text = "button", width = 10, height = 10, command = test_case)

root.wait_visibility()
#CORRIDOR_OPEN()
DECODE_INITIAL()
FINAL_SELF_CHECK()
CORRIDOR_OPEN()
root.mainloop()



#pattern1 : 0->3
#pattern2 : 4->7
#pattern3 : 8->11

#CASE  RED BLK YELLOW  1 1 1
#	   RED RED RED  3 0 0
#		RED RED BLUE 2 0 1
#		RED BLUE BLUE 1 2 0 
#		RED BLUE RED 2 1 0
